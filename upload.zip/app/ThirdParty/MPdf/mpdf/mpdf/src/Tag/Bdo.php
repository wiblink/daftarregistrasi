<?php

namespace Mpdf\Tag;

class Bdo extends InlineTag
{


}
