<?php
require_once 'src/Exception.php';
require_once 'src/PHPMailer.php';
require_once 'src/SMTP.php';
require_once 'src/OAuth.php';
require_once 'vendor/autoload.php';

$mail = new PHPMailer\PHPMailer\PHPMailer($exception);
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
//Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
$mail->Port = 587;
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 0;

//Set the encryption system to use - ssl (deprecated) or tls
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->AuthType = 'XOAUTH2';
		
$provider = new League\OAuth2\Client\Provider\Google(
	[
		'clientId' => '',
		'clientSecret' => ''
	]
);

$mail->setOAuth(
	new PHPMailer\PHPMailer\OAuth(
		[
			'provider' => $provider,
			'clientId' => '',
			'clientSecret' => '',
			'refreshToken' => '',
			'userName' => '',
		]
	)
);
	
$mail->CharSet = 'utf-8';
$mail->setFrom('', 'Nama Pengirim');
$mail->addAddress('', 'Nama Tujuan');
$mail->Subject = 'Tes Email';
$mail->msgHTML('Tes kirim email menggunakan PHPMailer dan GMail OAuth');
// $mail->AltBody = 'This is a plain-text message body';
		
if ($mail->send()) {
	echo 'Email berhasil dikirim';
} else {
	echo "Mailer Error: " . $mail->ErrorInfo;
}